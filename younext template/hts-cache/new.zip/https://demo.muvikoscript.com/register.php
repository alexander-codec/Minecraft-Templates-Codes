<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'>
    <meta name="viewport" content="width=device-width" />
    <title>Sign Up</title>
    <link rel="shortcut icon" type="image/png" href="https://demo.muvikoscript.com/img/favicon.png">
    <!-- Plugins -->
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/bootstrap3/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://demo.muvikoscript.com/themes/flixer/assets/css/owl.carousel.css">
    <link rel="stylesheet" href="https://demo.muvikoscript.com/themes/flixer/assets/css/owl.transitions.css">
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/jquery.mCustomScrollbar.min.css" rel="stylesheet">
    <script src="https://demo.muvikoscript.com/themes/flixer/assets/jwplayer/jwplayer.js"></script>
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/animate.css" rel="stylesheet">
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/chosen.min.css" rel="stylesheet">
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/chosen-bootstrap.css" rel="stylesheet">
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/tel-input/css/intlTelInput.css" rel="stylesheet">
    <script src="https://demo.muvikoscript.com/themes/flixer/assets/js/nprogress.js"></script>
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/nprogress.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
    <!-- Main CSS -->
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/plugins.css" rel="stylesheet">
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/theme.css" rel="stylesheet">
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/style.css" rel="stylesheet">
    <!--  Fonts and icons     -->
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/icomoon.css" rel="stylesheet" type="text/css" />
    <link href="https://demo.muvikoscript.com/themes/flixer/assets/css/themify-icons.css" rel="stylesheet" type="text/css" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script>
    var base = 'https://demo.muvikoscript.com/themes/flixer';
    var uploads_path = 'https://demo.muvikoscript.com/uploads';
    var user_id = '';
    jwplayer.key='ZyhJxcZOVHN31Dyb/lJ3yKqsIxUDlXfTiPdsdw==';
    NProgress.start();
    </script>
</head>
<body ><nav class="navbar navbar-fixed-top navbar-ct-transparent" role="navigation-demo">
 <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="https://demo.muvikoscript.com/index.php"><img src="https://demo.muvikoscript.com/themes/flixer/assets/images/logo.png"></a>
  </div>
  <div class="collapse navbar-collapse" id="navigation-example-2">
    <ul class="nav navbar-nav navbar-left">
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Browse <b class="caret"></b> </a>
        <ul class="dropdown-menu dropdown-menu-right">
          <li><a href="https://demo.muvikoscript.com/videos">Videos</a></li>
          <li><a href="https://demo.muvikoscript.com/series">Series</a></li>
        </ul>
      </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <form action="https://demo.muvikoscript.com/search.php" method="get" class="navbar-form navbar-left" style="display:none;" role="search">
        <div class="form-group">
         <div class="input-group search-input">
          <span class="input-group-addon" id="basic-addon1"><i class="ti-search"></i></span>
          <input type="text" name="q" class="form-control border-input" placeholder="Title">
        </div>
      </div>
    </form>
    <li id="search-toggle"> <a href="#" onclick="showSearch();"> <i class="ti-search"></i> &nbsp <span>Search</span> </a> </li>
        <li>
      <a href="#" class="btn btn-danger btn-fill" data-toggle="modal" data-target="#login">Sign In</a>
    </li>
      </ul>
</div>
</div>
</nav>
<div class="container animated fadeIn" onclick="hideSearch();">
  <div class="row">
    <div class="col-lg-12">
      <div class="col-md-5 centered pricing-page">
        <div class="panel panel-danger">
         <div class="panel-heading"><h3 class="text-center">Premium</h3></div>
         <div class="panel-body text-center">
           <p class="lead" style="font-size:40px">
            <strong>
              $0              <span>/month</span>
            </strong>
          </p>
        </div>
        <ul class="list-group list-group-flush text-center">
          <li class="list-group-item"><i class="icon-ok text-danger"></i> Unlimited Movies & Series</li>
          <li class="list-group-item"><i class="icon-ok text-danger"></i> Share your account with up to 4 people</li>
          <li class="list-group-item"><i class="icon-ok text-danger"></i> Create a playlist with your favorite movies</li>
        </ul>
        <div class="panel-footer">
         <a class="btn btn-danger btn-block btn-fill" data-toggle="modal" data-target="#pay">SUBSCRIBE</a>
       </div>
     </div>
   </div>
 </div>
</div>
</div>
<div class="modal fade" id="pay" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content payment-modal">
      <div class="modal-body">
        <div class="panel panel-danger"> 
          <div class="panel-heading"> 
            <div class="panel-title"> 
              Sign Up              <div class="pull-right">
                <span>Secure Form</span>
                <img src="https://demo.muvikoscript.com/themes/flixer/assets/images/padlock.png">
              </div>
            </div>
          </div>
          <div class="panel-body">
            <form action="" method="post">
              <div class="form-group">
                <label>
                  <span>Full Name*</span>
                </label>
                <input type="text" name="full_name" required class="form-control"/>
              </div>
              <div class="form-group">
                <label>
                  <span>Email*</span>
                </label>
                <input type="text" name="email" required class="form-control"/>
              </div>
              <div class="form-group">
                <label>
                  <span>Password*</span>
                </label>
                <input type="password" name="password" required class="form-control"/>
              </div>
              <div class="form-group">
                <label>
                  <span>Phone</span>
                </label>
                <input type="text" name="phone" class="form-control"/>
              </div>
              <button type="submit" name="continue" class="btn btn-danger btn-fill pull-right">Continue</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><footer class="footer footer-black footer-big">
<div class="container">
<div class="row">
<div class="col-md-9 col-md-offset-1 col-sm-9 col-xs-12">
<div class="row">
<div class="col-md-3 col-sm-3 col-xs-6">
<div class="links">
<ul class="stacked-links">
	<li><big>Categories</big></li>
			<li>
			<a href="https://demo.muvikoscript.com/category/12/horror">
				Horror			</a>
		</li>
				<li>
			<a href="https://demo.muvikoscript.com/category/11/sci-fi">
				Sci-Fi			</a>
		</li>
				<li>
			<a href="https://demo.muvikoscript.com/category/2/drama">
				Drama			</a>
		</li>
			</ul>
</div>
</div>
<div class="col-md-3 col-sm-3 col-xs-6">
<div class="links">
	<ul class="stacked-links">
		<li><big>Pages</big></li>
					<li>
				<a href="https://demo.muvikoscript.com/page/1">
					About Us				</a>
			</li>
						<li>
				<a href="https://demo.muvikoscript.com/page/2">
					Contact Us				</a>
			</li>
					</ul>
	</div>
</div>
<div class="col-md-3 col-sm-3 col-xs-6">
	<div class="links">
		<ul class="stacked-links">
			<li><big>Social</big></li>
						<li>
				<a href="https://www.facebook.com/envato" target="_blank">
					Facebook
				</a>
			</li>
									<li>
				<a href="https://twitter.com/envato" target="_blank">
					Twitter
				</a>
			</li>
					</ul>
	</div>
</div>
<div class="col-md-3 col-sm-3 col-xs-6">
	<div class="links">
		<ul class="stacked-links">
						<li>
				<h4>1<br> <small>users</small></h4>
			</li>
			<li>
				<h4>12<br> <small>videos</small></h4>
			</li>
		</ul>
	</div>
</div>
</div>
<hr>
<div class="copyright">
<div class="pull-left">
	© 2017 Muviko</div>
<div class="links pull-right">
</div>
</div>
</div>
</div>
</div>
</footer>
<!--  Plugins -->
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/bootstrap3/js/bootstrap.js" type="text/javascript"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/ct-paper-checkbox.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/ct-paper-radio.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/owl.carousel.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/icomoon.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/chosen.jquery.min.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/tel-input/js/intlTelInput.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.js"></script>
<script type="text/javascript">
window.cookieconsent_options = {"message":"This website uses cookies to ensure you get the best experience while using it","dismiss":"Okay","learnMore":"More info","link":null,"theme":"light-top"};
</script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/1.0.10/cookieconsent.min.js"></script>
</script>
<!-- Main JS -->
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/app.js"></script>
<script src="https://demo.muvikoscript.com/themes/flixer/assets/js/theme.js"></script>
</body>
<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document">
<div class="modal-content payment-modal">
<div class="modal-body">
<div class="panel panel-danger"> 
	<div class="panel-heading"> 
		<div class="panel-title"> 
			Sign In		</div>
	</div>
	<div class="panel-body">
		<form action="https://demo.muvikoscript.com/login.php" method="post">
			<div class="form-group">
				<label>
					<span>Email</span>
				</label>
				<input type="email" name="email" required class="form-control" value="admin@admin.com">
			</div>
			<div class="form-group">
				<label>
					<span>Password</span>
				</label>
				<input type="password" name="password" required class="form-control" value="admin">
			</div>
			<button type="submit" name="login" class="btn btn-danger btn-fill pull-right">Sign In</button>
			<a href="https://demo.muvikoscript.com/register" class="btn btn-default btn-fill pull-right" style="margin-right:5px;">Create Account</a>
		</form>
	</div>
</div>
</div>
</div>
</div>
</div>
</html>