<!--  Plugins -->
<script src="THEME_PATH/assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="THEME_PATH/assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>
<script src="THEME_PATH/assets/bootstrap3/js/bootstrap.js" type="text/javascript"></script>
<script src="THEME_PATH/assets/js/ct-paper-checkbox.js"></script>
<script src="THEME_PATH/assets/js/ct-paper-radio.js"></script>
<script src="THEME_PATH/assets/js/owl.carousel.js"></script>
<script src="THEME_PATH/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="THEME_PATH/assets/js/icomoon.js"></script>
<script src="THEME_PATH/assets/js/chosen.jquery.min.js"></script>
<script src="THEME_PATH/assets/tel-input/js/intlTelInput.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.js"></script>
<script type="text/javascript">
window.cookieconsent_options = {"message":"This website uses cookies to ensure you get the best experience while using it","dismiss":"Okay","learnMore":"More info","link":null,"theme":"light-top"};
</script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/1.0.10/cookieconsent.min.js"></script>
</script>
<!-- Main JS -->
<script src="THEME_PATH/assets/js/app.js"></script>
<script src="THEME_PATH/assets/js/theme.js"></script>
</body>
<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document">
<div class="modal-content payment-modal">
<div class="modal-body">
<div class="panel panel-danger"> 
	<div class="panel-heading"> 
		<div class="panel-title"> 
			